﻿Public Class Form1
    Private Sub exitBtn_Click(sender As Object, e As EventArgs) Handles exitBtn.Click
        Me.Close()
    End Sub

    Private Sub resetBtn_Click(sender As Object, e As EventArgs) Handles resetBtn.Click
        hoursTxt.Text = ""
        payRateTxt.Text = ""
        grossPayLbl.Text = ""
        payRateTxt.Select()
    End Sub

    Private Sub calculateBtn_Click(sender As Object, e As EventArgs) Handles calculateBtn.Click
        'handle the type cast exception

        Try
            'declare variables
            Dim hours, payRate As Double
            Dim grossPay, overTime As Double

            hours = hoursTxt.Text
            payRate = payRateTxt.Text

            'check for the valid hours and payrate entered
            'hours and payrate >0
            If hours < 0 Or payRate < 0 Then
                MessageBox.Show("Enter positive values")
            Else 'if the user enters positive values

                If hours > 40 Then 'pay for OT hours
                    overTime = hours - 40
                    grossPay = (payRate * 40) + (payRate * 1.5 * overTime)
                Else 'pay for regular hours
                    grossPay = payRate * hours
                End If

                'display the output
                grossPayLbl.Text = grossPay.ToString("C")
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class
