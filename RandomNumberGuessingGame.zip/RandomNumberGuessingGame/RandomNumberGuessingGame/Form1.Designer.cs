﻿namespace RandomNumberGuessingGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.inputTXT = new System.Windows.Forms.TextBox();
            this.guessbTN = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.correctTotalLBL = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter your guess";
            // 
            // inputTXT
            // 
            this.inputTXT.Location = new System.Drawing.Point(212, 39);
            this.inputTXT.Name = "inputTXT";
            this.inputTXT.Size = new System.Drawing.Size(100, 22);
            this.inputTXT.TabIndex = 1;
            // 
            // guessbTN
            // 
            this.guessbTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guessbTN.Location = new System.Drawing.Point(97, 130);
            this.guessbTN.Name = "guessbTN";
            this.guessbTN.Size = new System.Drawing.Size(138, 52);
            this.guessbTN.TabIndex = 2;
            this.guessbTN.Text = "Guess";
            this.guessbTN.UseVisualStyleBackColor = true;
            this.guessbTN.Click += new System.EventHandler(this.guessbTN_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(444, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "Total Correct";
            // 
            // correctTotalLBL
            // 
            this.correctTotalLBL.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.correctTotalLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.correctTotalLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.correctTotalLBL.Location = new System.Drawing.Point(434, 71);
            this.correctTotalLBL.Name = "correctTotalLBL";
            this.correctTotalLBL.Size = new System.Drawing.Size(157, 66);
            this.correctTotalLBL.TabIndex = 4;
            this.correctTotalLBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.correctTotalLBL);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.guessbTN);
            this.Controls.Add(this.inputTXT);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputTXT;
        private System.Windows.Forms.Button guessbTN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label correctTotalLBL;
    }
}

