﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomNumberGuessingGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        //declare counter for random guesses
        int count = 0;
        int correct = 0;
        private static readonly
        //declare a new random number and generate number
        Random rand = new Random();
        int randomNumber = rand.Next(101);

        private void guessbTN_Click(object sender, EventArgs e)
        {          

            //store user input into a variable
            int guess = int.Parse(inputTXT.Text);

            if (guess == randomNumber)
                {
                MessageBox.Show("Congratulations! Guess again.");
                    randomNumber = rand.Next(101);
                count += 1;
                correct = count;
                }
            else if (guess > randomNumber)
            {
                MessageBox.Show("Number is to high, try again");
            }
            else if (guess < randomNumber)
            {
                MessageBox.Show("Number is to low, try again");
            }

            correctTotalLBL.Text = correct.ToString();
        }
    }
}
