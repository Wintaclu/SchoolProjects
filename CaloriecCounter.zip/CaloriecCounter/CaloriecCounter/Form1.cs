﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaloriecCounter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int totalCalories = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            // when the form loads the total calories is 0
            totalCaloriesLBL.Text = totalCalories.ToString(); //0
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            totalCalories = totalCalories + 80;
            totalCaloriesLBL.Text = totalCalories.ToString();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            totalCalories = totalCalories + 115;
            totalCaloriesLBL.Text = totalCalories.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            totalCalories = totalCalories + 90;
            totalCaloriesLBL.Text = totalCalories.ToString();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            totalCalories = totalCalories + 120;
            totalCaloriesLBL.Text = totalCalories.ToString();
        }

        private void resetBTN_Click(object sender, EventArgs e)
        {
            totalCalories = 0;
            totalCaloriesLBL.Text = totalCalories.ToString();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
