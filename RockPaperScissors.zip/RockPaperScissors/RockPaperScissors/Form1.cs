﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RockPaperScissors
{
    public partial class Form1 : Form
    {
        int rock = 0;
        int paper = 1;
        int scissors = 2;
        public Form1()
        {
            InitializeComponent();


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void rockBTN_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int randomNumber = rand.Next(3);


            if (rock == randomNumber)
            {
                outputLBL.Text = ("It's a tie, try again! Computer chose rock");

            }
            else if (randomNumber == 1)
            {
                outputLBL.Text = ("You Lose! computer chose paper");
            }
            else
            {
                outputLBL.Text = ("You Win! Computer chose scissors");
            }
        }

        private void paperBTN_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int randomNumber = rand.Next(3);


            if (paper == randomNumber)
            {
                outputLBL.Text = ("It's a tie, try again! Computer chose Paper");
            }
            else if (randomNumber == 0)
            {
                outputLBL.Text = ("You Win! Computer chose rock");
            }
            else
            {
                outputLBL.Text = ("You Lose! Computer chose scissors");
            }
        }

        private void scissorsBTN_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int randomNumber = rand.Next(3);


            if (scissors == randomNumber)
            {
                outputLBL.Text = ("It's a tie, try again! Computer chose scissors");
            }
            else if (randomNumber == 1)
            {
                outputLBL.Text = ("You Win! Computer chose paper");
            }
            else
            {
                outputLBL.Text = ("You lose! Computer chose rock");
            }
        }
    }
}
