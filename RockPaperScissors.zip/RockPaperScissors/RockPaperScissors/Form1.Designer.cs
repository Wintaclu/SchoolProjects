﻿namespace RockPaperScissors
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rockPIC = new System.Windows.Forms.PictureBox();
            this.paperPIC = new System.Windows.Forms.PictureBox();
            this.scissorsPIC = new System.Windows.Forms.PictureBox();
            this.outputLBL = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rockBTN = new System.Windows.Forms.Button();
            this.paperBTN = new System.Windows.Forms.Button();
            this.scissorsBTN = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.rockPIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPIC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPIC)).BeginInit();
            this.SuspendLayout();
            // 
            // rockPIC
            // 
            this.rockPIC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.rockPIC.Image = ((System.Drawing.Image)(resources.GetObject("rockPIC.Image")));
            this.rockPIC.Location = new System.Drawing.Point(45, 73);
            this.rockPIC.Name = "rockPIC";
            this.rockPIC.Size = new System.Drawing.Size(174, 159);
            this.rockPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.rockPIC.TabIndex = 0;
            this.rockPIC.TabStop = false;
            this.rockPIC.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // paperPIC
            // 
            this.paperPIC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paperPIC.Image = ((System.Drawing.Image)(resources.GetObject("paperPIC.Image")));
            this.paperPIC.Location = new System.Drawing.Point(297, 73);
            this.paperPIC.Name = "paperPIC";
            this.paperPIC.Size = new System.Drawing.Size(174, 159);
            this.paperPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.paperPIC.TabIndex = 2;
            this.paperPIC.TabStop = false;
            // 
            // scissorsPIC
            // 
            this.scissorsPIC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.scissorsPIC.Image = ((System.Drawing.Image)(resources.GetObject("scissorsPIC.Image")));
            this.scissorsPIC.Location = new System.Drawing.Point(550, 73);
            this.scissorsPIC.Name = "scissorsPIC";
            this.scissorsPIC.Size = new System.Drawing.Size(174, 159);
            this.scissorsPIC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.scissorsPIC.TabIndex = 3;
            this.scissorsPIC.TabStop = false;
            // 
            // outputLBL
            // 
            this.outputLBL.BackColor = System.Drawing.Color.Lavender;
            this.outputLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLBL.Location = new System.Drawing.Point(123, 332);
            this.outputLBL.Name = "outputLBL";
            this.outputLBL.Size = new System.Drawing.Size(515, 78);
            this.outputLBL.TabIndex = 4;
            this.outputLBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(293, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(193, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Choose your fighter";
            // 
            // rockBTN
            // 
            this.rockBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rockBTN.Location = new System.Drawing.Point(85, 34);
            this.rockBTN.Name = "rockBTN";
            this.rockBTN.Size = new System.Drawing.Size(102, 36);
            this.rockBTN.TabIndex = 9;
            this.rockBTN.Text = "Rock";
            this.rockBTN.UseVisualStyleBackColor = true;
            this.rockBTN.Click += new System.EventHandler(this.rockBTN_Click);
            // 
            // paperBTN
            // 
            this.paperBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paperBTN.Location = new System.Drawing.Point(333, 36);
            this.paperBTN.Name = "paperBTN";
            this.paperBTN.Size = new System.Drawing.Size(102, 36);
            this.paperBTN.TabIndex = 10;
            this.paperBTN.Text = "Paper";
            this.paperBTN.UseVisualStyleBackColor = true;
            this.paperBTN.Click += new System.EventHandler(this.paperBTN_Click);
            // 
            // scissorsBTN
            // 
            this.scissorsBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scissorsBTN.Location = new System.Drawing.Point(585, 36);
            this.scissorsBTN.Name = "scissorsBTN";
            this.scissorsBTN.Size = new System.Drawing.Size(102, 36);
            this.scissorsBTN.TabIndex = 11;
            this.scissorsBTN.Text = "Scissors";
            this.scissorsBTN.UseVisualStyleBackColor = true;
            this.scissorsBTN.Click += new System.EventHandler(this.scissorsBTN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.scissorsBTN);
            this.Controls.Add(this.paperBTN);
            this.Controls.Add(this.rockBTN);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.outputLBL);
            this.Controls.Add(this.scissorsPIC);
            this.Controls.Add(this.paperPIC);
            this.Controls.Add(this.rockPIC);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.rockPIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPIC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPIC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox rockPIC;
        private System.Windows.Forms.PictureBox paperPIC;
        private System.Windows.Forms.PictureBox scissorsPIC;
        private System.Windows.Forms.Label outputLBL;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button rockBTN;
        private System.Windows.Forms.Button paperBTN;
        private System.Windows.Forms.Button scissorsBTN;
    }
}

