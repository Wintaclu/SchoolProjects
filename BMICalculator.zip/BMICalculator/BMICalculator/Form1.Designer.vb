﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.weightTXT = New System.Windows.Forms.TextBox()
        Me.heightTXT = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.bmiIndexLBL = New System.Windows.Forms.Label()
        Me.displayTXT = New System.Windows.Forms.TextBox()
        Me.calculateBTN = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(43, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(273, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter your weight in pounds"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(54, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(262, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Enter your height in inches"
        '
        'weightTXT
        '
        Me.weightTXT.Location = New System.Drawing.Point(322, 41)
        Me.weightTXT.Name = "weightTXT"
        Me.weightTXT.Size = New System.Drawing.Size(148, 20)
        Me.weightTXT.TabIndex = 2
        '
        'heightTXT
        '
        Me.heightTXT.Location = New System.Drawing.Point(322, 85)
        Me.heightTXT.Name = "heightTXT"
        Me.heightTXT.Size = New System.Drawing.Size(148, 20)
        Me.heightTXT.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(53, 153)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(192, 25)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Body Mass Index"
        '
        'bmiIndexLBL
        '
        Me.bmiIndexLBL.BackColor = System.Drawing.Color.MistyRose
        Me.bmiIndexLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.bmiIndexLBL.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bmiIndexLBL.Location = New System.Drawing.Point(251, 153)
        Me.bmiIndexLBL.Name = "bmiIndexLBL"
        Me.bmiIndexLBL.Size = New System.Drawing.Size(219, 25)
        Me.bmiIndexLBL.TabIndex = 5
        Me.bmiIndexLBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'displayTXT
        '
        Me.displayTXT.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.displayTXT.Location = New System.Drawing.Point(47, 195)
        Me.displayTXT.Multiline = True
        Me.displayTXT.Name = "displayTXT"
        Me.displayTXT.Size = New System.Drawing.Size(488, 176)
        Me.displayTXT.TabIndex = 6
        '
        'calculateBTN
        '
        Me.calculateBTN.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calculateBTN.Location = New System.Drawing.Point(116, 405)
        Me.calculateBTN.Name = "calculateBTN"
        Me.calculateBTN.Size = New System.Drawing.Size(218, 68)
        Me.calculateBTN.TabIndex = 7
        Me.calculateBTN.Text = "Calculate BMI"
        Me.calculateBTN.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(585, 504)
        Me.Controls.Add(Me.calculateBTN)
        Me.Controls.Add(Me.displayTXT)
        Me.Controls.Add(Me.bmiIndexLBL)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.heightTXT)
        Me.Controls.Add(Me.weightTXT)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents weightTXT As TextBox
    Friend WithEvents heightTXT As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents bmiIndexLBL As Label
    Friend WithEvents displayTXT As TextBox
    Friend WithEvents calculateBTN As Button
End Class
