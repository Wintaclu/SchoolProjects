﻿Public Class Form1
    Private Sub calculateBTN_Click(sender As Object, e As EventArgs) Handles calculateBTN.Click
        'Declare input and output variables
        Dim weight, height, bmi As Decimal

        weight = weightTXT.Text
        height = heightTXT.Text

        bmi = (weight * 703) / (height * weight)

        bmiIndexLBL.Text = bmi.ToString("n2")

        displayTXT.AppendText("BMI Values" & vbCrLf)

        displayTXT.AppendText("Underweight: less than 18.5" & vbCrLf)

        displayTXT.AppendText("Normal: Between 18.5 and 24.9" & vbCrLf)
        displayTXT.AppendText("Overweight: between 25 and 29.9" & vbCrLf)
        displayTXT.AppendText("Obese: 30 or greater" & vbCrLf)
    End Sub


End Class
