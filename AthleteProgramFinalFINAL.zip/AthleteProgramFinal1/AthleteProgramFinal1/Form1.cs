﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace AthleteProgramFinal1
{
    public partial class AthleteProgram : Form
    {
        public AthleteProgram()
        {
            
            InitializeComponent();
            athleteInformationGB.Visible = false;
            athleteSubBTN.Visible = false;
            professionalGB.Visible = false;
            professionalSubBTN.Visible = false;
            lawyerRB.Visible = false;
            paRB.Visible = false;
            agentRB.Visible = false;
            trainerRB.Visible = false;
            calcBTN.Visible = false;
            summaryGB.Visible = false;
            //sets the lawyer button to true so that they can't forget it
            lawyerRB.Checked = true;
        }


        private void editAthleteInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Controls: athleteInformationGB  athleteSubBTN  athleteNameTXT  athleteSalTXT
            athleteInformationGB.Visible = true;
            athleteSubBTN.Visible = true;
            professionalGB.Visible = false;
            professionalSubBTN.Visible = false;
            lawyerRB.Visible = false;
            paRB.Visible = false;
            agentRB.Visible = false;
            trainerRB.Visible = false;
            calcBTN.Visible = false;
            summaryGB.Visible = false;
        }
        //Button to submit athlete information
        private void athleteSubBTN_Click(object sender, EventArgs e)
        {
            try {
                string athleteName = "";
                double salary = 0;

                if (athleteNameTXT.Text != "")
                {
                    athleteName = athleteNameTXT.Text;

                    if (double.Parse(athleteSalTXT.Text) > 0)
                    {
                        salary = double.Parse(athleteSalTXT.Text);
                        MessageBox.Show("Successfully entered athlete information");
                    }
                    else if (double.Parse(athleteSalTXT.Text) <= 0)
                    {
                        MessageBox.Show("Please enter a positive number.");
                    }
                    else
                    {
                        MessageBox.Show("Please enter a number");
                    }


                }
                else
                {
                    MessageBox.Show("Please enter a name before continuing.");
                }


            } //end of try
            //catches the user leaving athleteSalTXT blank or entring non numeric information
            catch (Exception)
                {
                MessageBox.Show("Please enter an number");
                }
            }

        private void addAProfessionalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //controls: professionalGB  professionalNameTXT  professionalSubBTN   lawyerRB  paRB  agentRB  trainerRB  

            athleteInformationGB.Visible = false;
            athleteSubBTN.Visible = false;
            professionalGB.Visible = true;
            professionalSubBTN.Visible = true;
            lawyerRB.Visible = true;
            paRB.Visible = true;
            agentRB.Visible = true;
            trainerRB.Visible = true;
            calcBTN.Visible = false;
            summaryGB.Visible = false;
        }

        
        private void professionalSubBTN_Click(object sender, EventArgs e)
        {
            string n;
            if (professionalNameTXT.Text != "")
            {
               n = professionalNameTXT.Text;

                string p="";

                if (lawyerRB.Checked)
                {
                    p = "Lawyer";
                }
                else if (paRB.Checked)
                {
                    p = "Personal Assistant";
                }
                else if (agentRB.Checked)
                {
                    p = "Agent";
                }
                else if (trainerRB.Checked)
                {
                    p = "Trainer";
                }

                ProfessionalClass prof = new ProfessionalClass(n, p);

                this.professionalTableAdapter.InsertQuery(prof.Name, prof.Prof);
                MessageBox.Show("You have successfully entered data for: "+n);
            }
            else
            {
                MessageBox.Show("Enter a name");
            }
            
            

        }

        private void lawyerRB_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void paRB_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void agentRB_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void trainerRB_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void dataGridToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Controls  dataGridGB  catSortBTN  IDSortBTN
            //athleteInformationGB.Visible = false;
            //athleteSubBTN.Visible = false;
            //professionalGB.Visible = false;
            //professionalSubBTN.Visible = false;
            //lawyerRB.Visible = false;
            //paRB.Visible = false;
            //agentRB.Visible = false;
            //trainerRB.Visible = false;
            //dataGridGB.Visible = true;
            //catSortBTN.Visible = true;
            //IDSortBTN.Visible = true;
            //detailGB.Visible = false;
            //summaryGB.Visible = false;
            tableView f = new tableView();
            f.ShowDialog();

        }
        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.professionalBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.professionalDataSet);
        }

            private void catSortBTN_Click(object sender, EventArgs e)
        {

        }

        private void IDSortBTN_Click(object sender, EventArgs e)
        {

        }

        private void detailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Controla: detailGB
            athleteInformationGB.Visible = false;
            athleteSubBTN.Visible = false;
            professionalGB.Visible = false;
            professionalSubBTN.Visible = false;
            lawyerRB.Visible = false;
            paRB.Visible = false;
            agentRB.Visible = false;
            trainerRB.Visible = false;
            calcBTN.Visible = false;
            summaryGB.Visible = false;

            DetailView d = new DetailView();
            d.ShowDialog();
        }

        private void summaryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Controls: summaryGB  agentPaid  lawPaid  PAPaid  trainerPaid  totalPaid  totalRem  calcBTN
            athleteInformationGB.Visible = false;
            athleteSubBTN.Visible = false;
            professionalGB.Visible = false;
            professionalSubBTN.Visible = false;
            lawyerRB.Visible = false;
            paRB.Visible = false;
            agentRB.Visible = false;
            trainerRB.Visible = false;
            summaryGB.Visible = true;
            calcBTN.Visible = true;
        }

        private void calcBTN_Click(object sender, EventArgs e)
        {
            double AGENT = 0.07;
            double LAWYER = 0.1;
            double PA = 0.03;
            double TRAINER = 0.05;
            double totalPaid = 0;
            double totalRem = 0;
            double agentPaid = 0;
            double lawyerPaid = 0;
            double PAPaid = 0;
            double trainerPaid = 0;

            //get values from the database
            double numLaw = (double)this.professionalTableAdapter.LawyerQuery();
            double numAgent = (double)this.professionalTableAdapter.AgentQuery();
            double numPA = (double)this.professionalTableAdapter.PAQuery();
            double numTrainer = (double)this.professionalTableAdapter.TrainerQuery();

            try
            {
               
                double salary = 0;

                    if (double.Parse(athleteSalTXT.Text) > 0)
                    {
                        salary = double.Parse(athleteSalTXT.Text);
                        
                        agentPaid = (AGENT * salary) * numAgent;
                        lawyerPaid = (LAWYER * salary) * numLaw;
                        PAPaid = (PA * salary) * numPA;
                        trainerPaid = (TRAINER * salary) * numTrainer;

                        totalPaid = agentPaid + lawyerPaid + trainerPaid + PAPaid;
                        totalRem = salary - totalPaid;

                        agentPaidTXT.Text = agentPaid.ToString("C");
                        lawPaidTXT.Text = lawyerPaid.ToString("C");
                        PAPaidTXT.Text = PAPaid.ToString("C");
                        trainerPaidTXT.Text = trainerPaid.ToString("C");
                        totalPaidTXT.Text = totalPaid.ToString("C");
                        totalRemTXT.Text = totalRem.ToString("C");
                }
                    else if (double.Parse(athleteSalTXT.Text) <= 0)
                    {
                        MessageBox.Show("Please enter athlete Salary.");
                    }
                    else
                    {
                        MessageBox.Show("Please enter athlete salary.");
                    }


            } //end of try
            //catches the user leaving athleteSalTXT blank or entring non numeric information
            catch (Exception)
            {
                MessageBox.Show("Please enter athlete salary.");
            }

        }

        private void professionalBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.professionalBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.professionalDataSet);

        }

        private void AthleteProgram_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'professionalDataSet.Professional' table. You can move, or remove it, as needed.
            this.professionalTableAdapter.Fill(this.professionalDataSet.Professional);

        }

        private void summaryGB_Enter(object sender, EventArgs e)
        {

        }

        
    }
}
