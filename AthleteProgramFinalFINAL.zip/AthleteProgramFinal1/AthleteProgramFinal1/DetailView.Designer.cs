﻿namespace AthleteProgramFinal1
{
    partial class DetailView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label professionalIDLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label categoryLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DetailView));
            this.professionalDataSet = new AthleteProgramFinal1.ProfessionalDataSet();
            this.professionalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.professionalTableAdapter = new AthleteProgramFinal1.ProfessionalDataSetTableAdapters.ProfessionalTableAdapter();
            this.tableAdapterManager = new AthleteProgramFinal1.ProfessionalDataSetTableAdapters.TableAdapterManager();
            this.professionalBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.professionalBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.professionalIDTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.categoryTextBox = new System.Windows.Forms.TextBox();
            this.detailGB = new System.Windows.Forms.GroupBox();
            professionalIDLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            categoryLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.professionalDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.professionalBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.professionalBindingNavigator)).BeginInit();
            this.professionalBindingNavigator.SuspendLayout();
            this.detailGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // professionalIDLabel
            // 
            professionalIDLabel.AutoSize = true;
            professionalIDLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            professionalIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            professionalIDLabel.Location = new System.Drawing.Point(163, 104);
            professionalIDLabel.Name = "professionalIDLabel";
            professionalIDLabel.Size = new System.Drawing.Size(182, 29);
            professionalIDLabel.TabIndex = 1;
            professionalIDLabel.Text = "Professional ID:";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            nameLabel.Location = new System.Drawing.Point(186, 154);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(84, 29);
            nameLabel.TabIndex = 3;
            nameLabel.Text = "Name:";
            // 
            // categoryLabel
            // 
            categoryLabel.AutoSize = true;
            categoryLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            categoryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            categoryLabel.Location = new System.Drawing.Point(163, 206);
            categoryLabel.Name = "categoryLabel";
            categoryLabel.Size = new System.Drawing.Size(116, 29);
            categoryLabel.TabIndex = 5;
            categoryLabel.Text = "Category:";
            // 
            // professionalDataSet
            // 
            this.professionalDataSet.DataSetName = "ProfessionalDataSet";
            this.professionalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // professionalBindingSource
            // 
            this.professionalBindingSource.DataMember = "Professional";
            this.professionalBindingSource.DataSource = this.professionalDataSet;
            // 
            // professionalTableAdapter
            // 
            this.professionalTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ProfessionalTableAdapter = this.professionalTableAdapter;
            this.tableAdapterManager.UpdateOrder = AthleteProgramFinal1.ProfessionalDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // professionalBindingNavigator
            // 
            this.professionalBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.professionalBindingNavigator.BindingSource = this.professionalBindingSource;
            this.professionalBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.professionalBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.professionalBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.professionalBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.professionalBindingNavigatorSaveItem});
            this.professionalBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.professionalBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.professionalBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.professionalBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.professionalBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.professionalBindingNavigator.Name = "professionalBindingNavigator";
            this.professionalBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.professionalBindingNavigator.Size = new System.Drawing.Size(1003, 27);
            this.professionalBindingNavigator.TabIndex = 0;
            this.professionalBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Visible = false;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // professionalBindingNavigatorSaveItem
            // 
            this.professionalBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.professionalBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("professionalBindingNavigatorSaveItem.Image")));
            this.professionalBindingNavigatorSaveItem.Name = "professionalBindingNavigatorSaveItem";
            this.professionalBindingNavigatorSaveItem.Size = new System.Drawing.Size(24, 24);
            this.professionalBindingNavigatorSaveItem.Text = "Save Data";
            this.professionalBindingNavigatorSaveItem.Visible = false;
            this.professionalBindingNavigatorSaveItem.Click += new System.EventHandler(this.professionalBindingNavigatorSaveItem_Click);
            // 
            // professionalIDTextBox
            // 
            this.professionalIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.professionalBindingSource, "ProfessionalID", true));
            this.professionalIDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.professionalIDTextBox.Location = new System.Drawing.Point(351, 101);
            this.professionalIDTextBox.Name = "professionalIDTextBox";
            this.professionalIDTextBox.Size = new System.Drawing.Size(377, 34);
            this.professionalIDTextBox.TabIndex = 2;
            this.professionalIDTextBox.TextChanged += new System.EventHandler(this.professionalIDTextBox_TextChanged);
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.professionalBindingSource, "Name", true));
            this.nameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTextBox.Location = new System.Drawing.Point(285, 154);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(452, 34);
            this.nameTextBox.TabIndex = 4;
            // 
            // categoryTextBox
            // 
            this.categoryTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.professionalBindingSource, "Category", true));
            this.categoryTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryTextBox.Location = new System.Drawing.Point(285, 206);
            this.categoryTextBox.Name = "categoryTextBox";
            this.categoryTextBox.Size = new System.Drawing.Size(452, 34);
            this.categoryTextBox.TabIndex = 6;
            // 
            // detailGB
            // 
            this.detailGB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.detailGB.Controls.Add(this.professionalIDTextBox);
            this.detailGB.Controls.Add(professionalIDLabel);
            this.detailGB.Controls.Add(this.categoryTextBox);
            this.detailGB.Controls.Add(categoryLabel);
            this.detailGB.Controls.Add(nameLabel);
            this.detailGB.Controls.Add(this.nameTextBox);
            this.detailGB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detailGB.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.detailGB.Location = new System.Drawing.Point(43, 121);
            this.detailGB.Name = "detailGB";
            this.detailGB.Size = new System.Drawing.Size(878, 396);
            this.detailGB.TabIndex = 10;
            this.detailGB.TabStop = false;
            this.detailGB.Text = "Detail View";
            // 
            // DetailView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1003, 603);
            this.Controls.Add(this.detailGB);
            this.Controls.Add(this.professionalBindingNavigator);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Name = "DetailView";
            this.Text = "DetailView";
            this.Load += new System.EventHandler(this.DetailView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.professionalDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.professionalBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.professionalBindingNavigator)).EndInit();
            this.professionalBindingNavigator.ResumeLayout(false);
            this.professionalBindingNavigator.PerformLayout();
            this.detailGB.ResumeLayout(false);
            this.detailGB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ProfessionalDataSet professionalDataSet;
        private System.Windows.Forms.BindingSource professionalBindingSource;
        private ProfessionalDataSetTableAdapters.ProfessionalTableAdapter professionalTableAdapter;
        private ProfessionalDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator professionalBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton professionalBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox professionalIDTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox categoryTextBox;
        private System.Windows.Forms.GroupBox detailGB;
    }
}