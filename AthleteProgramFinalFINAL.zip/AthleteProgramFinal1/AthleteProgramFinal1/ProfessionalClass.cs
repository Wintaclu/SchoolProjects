﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AthleteProgramFinal1
{
    class ProfessionalClass
    {
        private string _name;
        private string _profession;

        //define propertis
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Prof
        {
            get { return _profession; }
            set { _profession = value; }
        }

        //define constructors
        public ProfessionalClass()
        {
            _name = ""; _profession = "";
        }

        public ProfessionalClass (string n, string p)
        {
            _name = n; _profession = p;
        }
    }
}
