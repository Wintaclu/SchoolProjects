﻿namespace AthleteProgramFinal1
{
    partial class AthleteProgram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AthleteProgram));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editAthleteInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addAProfessionalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.summaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.athleteInformationGB = new System.Windows.Forms.GroupBox();
            this.athleteSalTXT = new System.Windows.Forms.TextBox();
            this.athleteNameTXT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.athleteSubBTN = new System.Windows.Forms.Button();
            this.professionalGB = new System.Windows.Forms.GroupBox();
            this.trainerRB = new System.Windows.Forms.RadioButton();
            this.agentRB = new System.Windows.Forms.RadioButton();
            this.paRB = new System.Windows.Forms.RadioButton();
            this.lawyerRB = new System.Windows.Forms.RadioButton();
            this.professionalNameTXT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.professionalSubBTN = new System.Windows.Forms.Button();
            this.professionalBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.professionalDataSet = new AthleteProgramFinal1.ProfessionalDataSet();
            this.professionalTableAdapter = new AthleteProgramFinal1.ProfessionalDataSetTableAdapters.ProfessionalTableAdapter();
            this.tableAdapterManager = new AthleteProgramFinal1.ProfessionalDataSetTableAdapters.TableAdapterManager();
            this.summaryGB = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.calcBTN = new System.Windows.Forms.Button();
            this.totalRemTXT = new System.Windows.Forms.Label();
            this.totalPaidTXT = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.trainerPaidTXT = new System.Windows.Forms.Label();
            this.PAPaidTXT = new System.Windows.Forms.Label();
            this.lawPaidTXT = new System.Windows.Forms.Label();
            this.agentPaidTXT = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.athleteInformationGB.SuspendLayout();
            this.professionalGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.professionalBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.professionalDataSet)).BeginInit();
            this.summaryGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(782, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editAthleteInformationToolStripMenuItem,
            this.addAProfessionalToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.summaryToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editAthleteInformationToolStripMenuItem
            // 
            this.editAthleteInformationToolStripMenuItem.Name = "editAthleteInformationToolStripMenuItem";
            this.editAthleteInformationToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.editAthleteInformationToolStripMenuItem.Text = "Edit Athlete Information";
            this.editAthleteInformationToolStripMenuItem.Click += new System.EventHandler(this.editAthleteInformationToolStripMenuItem_Click);
            // 
            // addAProfessionalToolStripMenuItem
            // 
            this.addAProfessionalToolStripMenuItem.Name = "addAProfessionalToolStripMenuItem";
            this.addAProfessionalToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.addAProfessionalToolStripMenuItem.Text = "Add a Professional";
            this.addAProfessionalToolStripMenuItem.Click += new System.EventHandler(this.addAProfessionalToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataGridToolStripMenuItem,
            this.detailToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // dataGridToolStripMenuItem
            // 
            this.dataGridToolStripMenuItem.Name = "dataGridToolStripMenuItem";
            this.dataGridToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.dataGridToolStripMenuItem.Text = "Data Grid";
            this.dataGridToolStripMenuItem.Click += new System.EventHandler(this.dataGridToolStripMenuItem_Click);
            // 
            // detailToolStripMenuItem
            // 
            this.detailToolStripMenuItem.Name = "detailToolStripMenuItem";
            this.detailToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.detailToolStripMenuItem.Text = "Detail ";
            this.detailToolStripMenuItem.Click += new System.EventHandler(this.detailToolStripMenuItem_Click);
            // 
            // summaryToolStripMenuItem
            // 
            this.summaryToolStripMenuItem.Name = "summaryToolStripMenuItem";
            this.summaryToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.summaryToolStripMenuItem.Text = "Summary";
            this.summaryToolStripMenuItem.Click += new System.EventHandler(this.summaryToolStripMenuItem_Click);
            // 
            // athleteInformationGB
            // 
            this.athleteInformationGB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.athleteInformationGB.Controls.Add(this.athleteSalTXT);
            this.athleteInformationGB.Controls.Add(this.athleteNameTXT);
            this.athleteInformationGB.Controls.Add(this.label2);
            this.athleteInformationGB.Controls.Add(this.label1);
            this.athleteInformationGB.Controls.Add(this.athleteSubBTN);
            this.athleteInformationGB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.athleteInformationGB.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.athleteInformationGB.Location = new System.Drawing.Point(66, 55);
            this.athleteInformationGB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.athleteInformationGB.Name = "athleteInformationGB";
            this.athleteInformationGB.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.athleteInformationGB.Size = new System.Drawing.Size(634, 404);
            this.athleteInformationGB.TabIndex = 1;
            this.athleteInformationGB.TabStop = false;
            this.athleteInformationGB.Text = "Athlete Information";
            // 
            // athleteSalTXT
            // 
            this.athleteSalTXT.Location = new System.Drawing.Point(184, 193);
            this.athleteSalTXT.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.athleteSalTXT.Name = "athleteSalTXT";
            this.athleteSalTXT.Size = new System.Drawing.Size(296, 28);
            this.athleteSalTXT.TabIndex = 4;
            // 
            // athleteNameTXT
            // 
            this.athleteNameTXT.Location = new System.Drawing.Point(184, 110);
            this.athleteNameTXT.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.athleteNameTXT.Name = "athleteNameTXT";
            this.athleteNameTXT.Size = new System.Drawing.Size(296, 28);
            this.athleteNameTXT.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(121, 197);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Salary";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(121, 112);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name";
            // 
            // athleteSubBTN
            // 
            this.athleteSubBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(58)))));
            this.athleteSubBTN.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.athleteSubBTN.Location = new System.Drawing.Point(434, 317);
            this.athleteSubBTN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.athleteSubBTN.Name = "athleteSubBTN";
            this.athleteSubBTN.Size = new System.Drawing.Size(122, 32);
            this.athleteSubBTN.TabIndex = 0;
            this.athleteSubBTN.Text = "Submit";
            this.athleteSubBTN.UseVisualStyleBackColor = false;
            this.athleteSubBTN.Click += new System.EventHandler(this.athleteSubBTN_Click);
            // 
            // professionalGB
            // 
            this.professionalGB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.professionalGB.Controls.Add(this.trainerRB);
            this.professionalGB.Controls.Add(this.agentRB);
            this.professionalGB.Controls.Add(this.paRB);
            this.professionalGB.Controls.Add(this.lawyerRB);
            this.professionalGB.Controls.Add(this.professionalNameTXT);
            this.professionalGB.Controls.Add(this.label3);
            this.professionalGB.Controls.Add(this.label4);
            this.professionalGB.Controls.Add(this.professionalSubBTN);
            this.professionalGB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.professionalGB.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.professionalGB.Location = new System.Drawing.Point(64, 55);
            this.professionalGB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.professionalGB.Name = "professionalGB";
            this.professionalGB.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.professionalGB.Size = new System.Drawing.Size(656, 404);
            this.professionalGB.TabIndex = 5;
            this.professionalGB.TabStop = false;
            this.professionalGB.Text = "Add a Professional";
            // 
            // trainerRB
            // 
            this.trainerRB.AutoSize = true;
            this.trainerRB.Location = new System.Drawing.Point(92, 267);
            this.trainerRB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.trainerRB.Name = "trainerRB";
            this.trainerRB.Size = new System.Drawing.Size(88, 28);
            this.trainerRB.TabIndex = 7;
            this.trainerRB.TabStop = true;
            this.trainerRB.Text = "Trainer";
            this.trainerRB.UseVisualStyleBackColor = true;
            this.trainerRB.CheckedChanged += new System.EventHandler(this.trainerRB_CheckedChanged);
            // 
            // agentRB
            // 
            this.agentRB.AutoSize = true;
            this.agentRB.Location = new System.Drawing.Point(92, 236);
            this.agentRB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.agentRB.Name = "agentRB";
            this.agentRB.Size = new System.Drawing.Size(78, 28);
            this.agentRB.TabIndex = 6;
            this.agentRB.TabStop = true;
            this.agentRB.Text = "Agent";
            this.agentRB.UseVisualStyleBackColor = true;
            this.agentRB.CheckedChanged += new System.EventHandler(this.agentRB_CheckedChanged);
            // 
            // paRB
            // 
            this.paRB.AutoSize = true;
            this.paRB.Location = new System.Drawing.Point(92, 193);
            this.paRB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.paRB.Name = "paRB";
            this.paRB.Size = new System.Drawing.Size(180, 28);
            this.paRB.TabIndex = 5;
            this.paRB.TabStop = true;
            this.paRB.Text = "Personal Assistant";
            this.paRB.UseVisualStyleBackColor = true;
            this.paRB.CheckedChanged += new System.EventHandler(this.paRB_CheckedChanged);
            // 
            // lawyerRB
            // 
            this.lawyerRB.AutoSize = true;
            this.lawyerRB.Location = new System.Drawing.Point(92, 153);
            this.lawyerRB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lawyerRB.Name = "lawyerRB";
            this.lawyerRB.Size = new System.Drawing.Size(88, 28);
            this.lawyerRB.TabIndex = 4;
            this.lawyerRB.TabStop = true;
            this.lawyerRB.Text = "Lawyer";
            this.lawyerRB.UseVisualStyleBackColor = true;
            this.lawyerRB.CheckedChanged += new System.EventHandler(this.lawyerRB_CheckedChanged);
            // 
            // professionalNameTXT
            // 
            this.professionalNameTXT.Location = new System.Drawing.Point(124, 52);
            this.professionalNameTXT.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.professionalNameTXT.Name = "professionalNameTXT";
            this.professionalNameTXT.Size = new System.Drawing.Size(296, 28);
            this.professionalNameTXT.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(62, 108);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Category";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 54);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 24);
            this.label4.TabIndex = 1;
            this.label4.Text = "Name";
            // 
            // professionalSubBTN
            // 
            this.professionalSubBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(58)))));
            this.professionalSubBTN.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.professionalSubBTN.Location = new System.Drawing.Point(434, 317);
            this.professionalSubBTN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.professionalSubBTN.Name = "professionalSubBTN";
            this.professionalSubBTN.Size = new System.Drawing.Size(122, 32);
            this.professionalSubBTN.TabIndex = 0;
            this.professionalSubBTN.Text = "Submit";
            this.professionalSubBTN.UseVisualStyleBackColor = false;
            this.professionalSubBTN.Click += new System.EventHandler(this.professionalSubBTN_Click);
            // 
            // professionalBindingSource
            // 
            this.professionalBindingSource.DataMember = "Professional";
            this.professionalBindingSource.DataSource = this.professionalDataSet;
            // 
            // professionalDataSet
            // 
            this.professionalDataSet.DataSetName = "ProfessionalDataSet";
            this.professionalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // professionalTableAdapter
            // 
            this.professionalTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.ProfessionalTableAdapter = this.professionalTableAdapter;
            this.tableAdapterManager.UpdateOrder = AthleteProgramFinal1.ProfessionalDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // summaryGB
            // 
            this.summaryGB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(42)))), ((int)(((byte)(42)))));
            this.summaryGB.Controls.Add(this.label15);
            this.summaryGB.Controls.Add(this.label14);
            this.summaryGB.Controls.Add(this.label13);
            this.summaryGB.Controls.Add(this.label12);
            this.summaryGB.Controls.Add(this.calcBTN);
            this.summaryGB.Controls.Add(this.totalRemTXT);
            this.summaryGB.Controls.Add(this.totalPaidTXT);
            this.summaryGB.Controls.Add(this.label11);
            this.summaryGB.Controls.Add(this.label10);
            this.summaryGB.Controls.Add(this.trainerPaidTXT);
            this.summaryGB.Controls.Add(this.PAPaidTXT);
            this.summaryGB.Controls.Add(this.lawPaidTXT);
            this.summaryGB.Controls.Add(this.agentPaidTXT);
            this.summaryGB.Controls.Add(this.label9);
            this.summaryGB.Controls.Add(this.label8);
            this.summaryGB.Controls.Add(this.label7);
            this.summaryGB.Controls.Add(this.label6);
            this.summaryGB.Controls.Add(this.label5);
            this.summaryGB.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.summaryGB.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.summaryGB.Location = new System.Drawing.Point(62, 55);
            this.summaryGB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.summaryGB.Name = "summaryGB";
            this.summaryGB.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.summaryGB.Size = new System.Drawing.Size(658, 404);
            this.summaryGB.TabIndex = 9;
            this.summaryGB.TabStop = false;
            this.summaryGB.Text = "Summary";
            this.summaryGB.Enter += new System.EventHandler(this.summaryGB_Enter);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(390, 176);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "at 5% total earnings";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(390, 148);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "at 3% total earnings";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(390, 118);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(105, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "at 10% total earnings";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(390, 89);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "at 7% total earnings";
            // 
            // calcBTN
            // 
            this.calcBTN.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(58)))));
            this.calcBTN.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.calcBTN.Location = new System.Drawing.Point(517, 117);
            this.calcBTN.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.calcBTN.Name = "calcBTN";
            this.calcBTN.Size = new System.Drawing.Size(122, 32);
            this.calcBTN.TabIndex = 13;
            this.calcBTN.Text = "Calculate";
            this.calcBTN.UseVisualStyleBackColor = false;
            this.calcBTN.Click += new System.EventHandler(this.calcBTN_Click);
            // 
            // totalRemTXT
            // 
            this.totalRemTXT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.totalRemTXT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalRemTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalRemTXT.Location = new System.Drawing.Point(249, 301);
            this.totalRemTXT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.totalRemTXT.Name = "totalRemTXT";
            this.totalRemTXT.Size = new System.Drawing.Size(285, 32);
            this.totalRemTXT.TabIndex = 12;
            // 
            // totalPaidTXT
            // 
            this.totalPaidTXT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.totalPaidTXT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalPaidTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalPaidTXT.Location = new System.Drawing.Point(249, 228);
            this.totalPaidTXT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.totalPaidTXT.Name = "totalPaidTXT";
            this.totalPaidTXT.Size = new System.Drawing.Size(285, 32);
            this.totalPaidTXT.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 301);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(223, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Total Amount Remaining:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(82, 229);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(169, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "Total Amount Paid:";
            // 
            // trainerPaidTXT
            // 
            this.trainerPaidTXT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.trainerPaidTXT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.trainerPaidTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainerPaidTXT.Location = new System.Drawing.Point(178, 176);
            this.trainerPaidTXT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.trainerPaidTXT.Name = "trainerPaidTXT";
            this.trainerPaidTXT.Size = new System.Drawing.Size(206, 20);
            this.trainerPaidTXT.TabIndex = 8;
            // 
            // PAPaidTXT
            // 
            this.PAPaidTXT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.PAPaidTXT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.PAPaidTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PAPaidTXT.Location = new System.Drawing.Point(178, 148);
            this.PAPaidTXT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PAPaidTXT.Name = "PAPaidTXT";
            this.PAPaidTXT.Size = new System.Drawing.Size(206, 20);
            this.PAPaidTXT.TabIndex = 7;
            // 
            // lawPaidTXT
            // 
            this.lawPaidTXT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.lawPaidTXT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lawPaidTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lawPaidTXT.Location = new System.Drawing.Point(178, 117);
            this.lawPaidTXT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lawPaidTXT.Name = "lawPaidTXT";
            this.lawPaidTXT.Size = new System.Drawing.Size(206, 20);
            this.lawPaidTXT.TabIndex = 6;
            // 
            // agentPaidTXT
            // 
            this.agentPaidTXT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            this.agentPaidTXT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.agentPaidTXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.agentPaidTXT.Location = new System.Drawing.Point(179, 87);
            this.agentPaidTXT.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.agentPaidTXT.Name = "agentPaidTXT";
            this.agentPaidTXT.Size = new System.Drawing.Size(206, 20);
            this.agentPaidTXT.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(111, 176);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(66, 18);
            this.label9.TabIndex = 4;
            this.label9.Text = "Trainers:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(44, 148);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(143, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "Personal Assistants:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(111, 117);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "Lawyers:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(118, 87);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 18);
            this.label6.TabIndex = 1;
            this.label6.Text = "Agents:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 44);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "Amount paid to:";
            // 
            // AthleteProgram
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(29)))), ((int)(((byte)(29)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(782, 540);
            this.Controls.Add(this.summaryGB);
            this.Controls.Add(this.professionalGB);
            this.Controls.Add(this.athleteInformationGB);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "AthleteProgram";
            this.Text = "Athlete Program";
            this.Load += new System.EventHandler(this.AthleteProgram_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.athleteInformationGB.ResumeLayout(false);
            this.athleteInformationGB.PerformLayout();
            this.professionalGB.ResumeLayout(false);
            this.professionalGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.professionalBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.professionalDataSet)).EndInit();
            this.summaryGB.ResumeLayout(false);
            this.summaryGB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataGridToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem summaryToolStripMenuItem;
        private System.Windows.Forms.GroupBox athleteInformationGB;
        private System.Windows.Forms.TextBox athleteSalTXT;
        private System.Windows.Forms.TextBox athleteNameTXT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button athleteSubBTN;
        private System.Windows.Forms.ToolStripMenuItem editAthleteInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addAProfessionalToolStripMenuItem;
        private System.Windows.Forms.GroupBox professionalGB;
        private System.Windows.Forms.TextBox professionalNameTXT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button professionalSubBTN;
        private System.Windows.Forms.RadioButton lawyerRB;
        private System.Windows.Forms.RadioButton paRB;
        private System.Windows.Forms.RadioButton agentRB;
        private System.Windows.Forms.RadioButton trainerRB;
        private ProfessionalDataSet professionalDataSet;
        private System.Windows.Forms.BindingSource professionalBindingSource;
        private ProfessionalDataSetTableAdapters.ProfessionalTableAdapter professionalTableAdapter;
        private ProfessionalDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.GroupBox summaryGB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label totalRemTXT;
        private System.Windows.Forms.Label totalPaidTXT;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label trainerPaidTXT;
        private System.Windows.Forms.Label PAPaidTXT;
        private System.Windows.Forms.Label lawPaidTXT;
        private System.Windows.Forms.Label agentPaidTXT;
        private System.Windows.Forms.Button calcBTN;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
    }
}

