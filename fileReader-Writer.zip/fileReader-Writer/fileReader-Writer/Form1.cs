﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace fileReader_Writer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void writeBtn_Click(object sender, EventArgs e)
        {
            int number;//get the count of random numbers to be generated.
            number = int.Parse(numTxt.Text);

            //generate random numbers
            Random rand = new Random();

            //to write to the file
            StreamWriter outFile;
            //variable to store each random number
            int randomnumber;
           
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                //open the file
                outFile = File.CreateText(saveFile.FileName);

                for(int i = 0; i < number; i++)//genates the count of numbers
                {
                    randomnumber = rand.Next(100)+1;
                    //write to the file
                    outFile.WriteLine(randomnumber.ToString());
                }

                //close the file
                outFile.Close();
            }
            else
            {
                MessageBox.Show("Operation cancelled");
            }

        }

        private void readBtn_Click(object sender, EventArgs e)
        {
            StreamReader inFile;
            string line;//variable to hold the line rea from file
            int total = 0, count = 0;//accumulator to count and find total

            //check for the dialog box
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                //open the file
                inFile = File.OpenText(openFile.FileName);

                //read from the file
                while (!inFile.EndOfStream)
                {
                    line = inFile.ReadLine();
                    total += int.Parse(line);
                    count++;
                    numbersList.Items.Add(line);
                }

                //close the file
                inFile.Close();

                totalLbl.Text = total.ToString();//print sum
                countLbl.Text = count.ToString();//print the count of numbers in the file
            }
            else
            {
                MessageBox.Show("Operation cancelled");
            }
        }
    }
}
