﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace joeAutomotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double total=0;
        double taxTotal = 0;

        private void exitBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            //clear information using references
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }
        private void ClearOilLube()
            //clears oil and lube box
        {
            oilChangeBOX.Checked = false;
            lubeCheckBOX.Checked = false;
        }
        private void ClearFlushes()
            //clears flushes box
        {
            radiatorFlushBOX.Checked = false;
            transmissionFlushBOX.Checked = false;
        }
        private void ClearMisc()
            //clears misc box
        {
            inspectionBOX.Checked = false;
            replaceMufflerBOX.Checked = false;
            tireRotationBox.Checked = false;
        }
        private void ClearOther()
            // clears parts and labor box
        {
            partsTXT.Clear();
            laborTXT.Clear();
        }
        private void ClearFees()
            //clears Summary box
        {
            serviceLaborLBL.Text = "";
            partsLBL.Text = "";
            partsTaxLBL.Text = "";
            totalLBL.Text = "";
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            // Testing each portion of code to make sure it works
            //total of oil lube
            //MessageBox.Show(OilLubeCharges(total).ToString());
            // total of the flush
            //MessageBox.Show(FlushCharges(total).ToString());
            //Misc Charges
            //MessageBox.Show(MiscCharges(total).ToString());
            //other charges
            //MessageBox.Show(OtherCharges(total).ToString());
            //tax charges
            //MessageBox.Show(TaxCharges(taxTotal).ToString());
            //show total charges
            //MessageBox.Show(TotalCharges(total).ToString());

            double services;
            services = OilLubeCharges(total) + FlushCharges(total) + MiscCharges(total);

            serviceLaborLBL.Text = services.ToString();
            partsLBL.Text = OtherCharges(total).ToString();
            partsTaxLBL.Text = TaxCharges(taxTotal).ToString();
            totalLBL.Text = TotalCharges(total).ToString();
            

            //clear total in order to click button multiple times without previous values being stored
            total = 0; 
        }
        // oil and lube charges
        private double OilLubeCharges(double total)
        {
            double oilChange, lube;
            oilChange = 26.00;
            lube = 18.00;
            if (oilChangeBOX.Checked || lubeCheckBOX.Checked)
            {
                if (lubeCheckBOX.Checked)
                {
                    total += lube;
                }
                if (oilChangeBOX.Checked)
                {
                    total += oilChange;
                }
            }
            
            else
            {
                total += total;
            }
            
            return total;
        }
        // flush charges include radiator flush, transmission flush
        private double FlushCharges(double total)
        {
            double radiatorFlush, transmissionFlush;
            radiatorFlush = 30.0;
            transmissionFlush = 80.0;

            if (radiatorFlushBOX.Checked || transmissionFlushBOX.Checked)
            {
                if (radiatorFlushBOX.Checked)
                {
                    total += radiatorFlush;
                }
                if (transmissionFlushBOX.Checked)
                {
                    total += transmissionFlush;
                }
            }

            else
            {
                total += total;
            }

            return total;
        }

        // misc charges include inspection, muffler replacement, and tire rotation
        private double MiscCharges(double total)
        {
            double inspection, replaceMuffler, tireRotation;
            inspection = 15.00;
            replaceMuffler = 100.0;
            tireRotation = 20.0;

            if (inspectionBOX.Checked || replaceMufflerBOX.Checked)
            {
                if (inspectionBOX.Checked)
                {
                    total += inspection;
                }
                if (replaceMufflerBOX.Checked)
                {
                    total += replaceMuffler;
                }
            }
            if (tireRotationBox.Checked)
            {
                total += tireRotation;
            }

            else
            {
                total += total;
            }

            return total;
        }

        // charges for parts and labor
        private double OtherCharges(double total)
        {
            double parts, laborhrs, labor;

            if (partsTXT.Text == "")
            {
                parts = 0;
            }
            else
            {
                parts = double.Parse(partsTXT.Text);
            }
            if (laborTXT.Text == "")
            {
                labor = 0;
            }
            else
            {
                laborhrs = double.Parse(laborTXT.Text);
                labor = laborhrs * 20;
            }
            total = parts + labor;
            return total;
        }

        //tax charges
        private double TaxCharges(double taxTotal)
        {
            double tax= 0.06;
            double parts;
            if (partsTXT.Text == "")
            {
                parts = 0;
            }
            else
            {
                parts = double.Parse(partsTXT.Text);
            }
            taxTotal = (parts * tax)+ parts;

            return taxTotal;
        }

        private double TotalCharges(double total)
        {
            //display all totaled
            total = (OilLubeCharges(total) + (FlushCharges(total)) + (MiscCharges(total)) + (OtherCharges(total)) + (TaxCharges(taxTotal)));

            return total;
        }

    }
}
