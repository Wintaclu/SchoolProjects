﻿namespace joeAutomotive
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lubeCheckBOX = new System.Windows.Forms.CheckBox();
            this.oilChangeBOX = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.transmissionFlushBOX = new System.Windows.Forms.CheckBox();
            this.radiatorFlushBOX = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tireRotationBox = new System.Windows.Forms.CheckBox();
            this.replaceMufflerBOX = new System.Windows.Forms.CheckBox();
            this.inspectionBOX = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.laborTXT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.partsTXT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.totalLBL = new System.Windows.Forms.Label();
            this.partsTaxLBL = new System.Windows.Forms.Label();
            this.partsLBL = new System.Windows.Forms.Label();
            this.serviceLaborLBL = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lubeCheckBOX);
            this.groupBox1.Controls.Add(this.oilChangeBOX);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(51, 42);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(369, 178);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Oil and Lube";
            // 
            // lubeCheckBOX
            // 
            this.lubeCheckBOX.AutoSize = true;
            this.lubeCheckBOX.Location = new System.Drawing.Point(41, 105);
            this.lubeCheckBOX.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lubeCheckBOX.Name = "lubeCheckBOX";
            this.lubeCheckBOX.Size = new System.Drawing.Size(183, 28);
            this.lubeCheckBOX.TabIndex = 1;
            this.lubeCheckBOX.Text = "Lube Job ($18.00)";
            this.lubeCheckBOX.UseVisualStyleBackColor = true;
            // 
            // oilChangeBOX
            // 
            this.oilChangeBOX.AutoSize = true;
            this.oilChangeBOX.Location = new System.Drawing.Point(41, 50);
            this.oilChangeBOX.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.oilChangeBOX.Name = "oilChangeBOX";
            this.oilChangeBOX.Size = new System.Drawing.Size(199, 28);
            this.oilChangeBOX.TabIndex = 0;
            this.oilChangeBOX.Text = "Oil Change ($26.00)";
            this.oilChangeBOX.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.transmissionFlushBOX);
            this.groupBox2.Controls.Add(this.radiatorFlushBOX);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(508, 42);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(311, 183);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Flushes";
            // 
            // transmissionFlushBOX
            // 
            this.transmissionFlushBOX.AutoSize = true;
            this.transmissionFlushBOX.Location = new System.Drawing.Point(24, 105);
            this.transmissionFlushBOX.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.transmissionFlushBOX.Name = "transmissionFlushBOX";
            this.transmissionFlushBOX.Size = new System.Drawing.Size(268, 28);
            this.transmissionFlushBOX.TabIndex = 1;
            this.transmissionFlushBOX.Text = "Transmission Flush ($80.00)";
            this.transmissionFlushBOX.UseVisualStyleBackColor = true;
            // 
            // radiatorFlushBOX
            // 
            this.radiatorFlushBOX.AutoSize = true;
            this.radiatorFlushBOX.Location = new System.Drawing.Point(24, 50);
            this.radiatorFlushBOX.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radiatorFlushBOX.Name = "radiatorFlushBOX";
            this.radiatorFlushBOX.Size = new System.Drawing.Size(225, 28);
            this.radiatorFlushBOX.TabIndex = 0;
            this.radiatorFlushBOX.Text = "Radiator Flush ($30.00)";
            this.radiatorFlushBOX.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tireRotationBox);
            this.groupBox3.Controls.Add(this.replaceMufflerBOX);
            this.groupBox3.Controls.Add(this.inspectionBOX);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(51, 228);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox3.Size = new System.Drawing.Size(369, 229);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Misc";
            // 
            // tireRotationBox
            // 
            this.tireRotationBox.AutoSize = true;
            this.tireRotationBox.Location = new System.Drawing.Point(41, 143);
            this.tireRotationBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tireRotationBox.Name = "tireRotationBox";
            this.tireRotationBox.Size = new System.Drawing.Size(210, 28);
            this.tireRotationBox.TabIndex = 2;
            this.tireRotationBox.Text = "Tire Rotation ($20.00)";
            this.tireRotationBox.UseVisualStyleBackColor = true;
            // 
            // replaceMufflerBOX
            // 
            this.replaceMufflerBOX.AutoSize = true;
            this.replaceMufflerBOX.Location = new System.Drawing.Point(41, 92);
            this.replaceMufflerBOX.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.replaceMufflerBOX.Name = "replaceMufflerBOX";
            this.replaceMufflerBOX.Size = new System.Drawing.Size(245, 28);
            this.replaceMufflerBOX.TabIndex = 1;
            this.replaceMufflerBOX.Text = "Replace Muffler ($100.00)";
            this.replaceMufflerBOX.UseVisualStyleBackColor = true;
            // 
            // inspectionBOX
            // 
            this.inspectionBOX.AutoSize = true;
            this.inspectionBOX.Location = new System.Drawing.Point(41, 42);
            this.inspectionBOX.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.inspectionBOX.Name = "inspectionBOX";
            this.inspectionBOX.Size = new System.Drawing.Size(190, 28);
            this.inspectionBOX.TabIndex = 0;
            this.inspectionBOX.Text = "Inspection ($15.00)";
            this.inspectionBOX.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.laborTXT);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.partsTXT);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(508, 233);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox4.Size = new System.Drawing.Size(311, 224);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parts and Labor";
            // 
            // laborTXT
            // 
            this.laborTXT.Location = new System.Drawing.Point(153, 138);
            this.laborTXT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.laborTXT.Name = "laborTXT";
            this.laborTXT.Size = new System.Drawing.Size(132, 29);
            this.laborTXT.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(57, 144);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Labor";
            // 
            // partsTXT
            // 
            this.partsTXT.Location = new System.Drawing.Point(153, 54);
            this.partsTXT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.partsTXT.Name = "partsTXT";
            this.partsTXT.Size = new System.Drawing.Size(132, 29);
            this.partsTXT.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(57, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Parts";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.totalLBL);
            this.groupBox5.Controls.Add(this.partsTaxLBL);
            this.groupBox5.Controls.Add(this.partsLBL);
            this.groupBox5.Controls.Add(this.serviceLaborLBL);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(1000, 54);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox5.Size = new System.Drawing.Size(440, 402);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Summary";
            // 
            // totalLBL
            // 
            this.totalLBL.BackColor = System.Drawing.Color.LavenderBlush;
            this.totalLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLBL.Location = new System.Drawing.Point(159, 286);
            this.totalLBL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalLBL.Name = "totalLBL";
            this.totalLBL.Size = new System.Drawing.Size(255, 37);
            this.totalLBL.TabIndex = 8;
            // 
            // partsTaxLBL
            // 
            this.partsTaxLBL.BackColor = System.Drawing.Color.LavenderBlush;
            this.partsTaxLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.partsTaxLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.partsTaxLBL.Location = new System.Drawing.Point(177, 210);
            this.partsTaxLBL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.partsTaxLBL.Name = "partsTaxLBL";
            this.partsTaxLBL.Size = new System.Drawing.Size(236, 37);
            this.partsTaxLBL.TabIndex = 7;
            // 
            // partsLBL
            // 
            this.partsLBL.BackColor = System.Drawing.Color.LavenderBlush;
            this.partsLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.partsLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.partsLBL.Location = new System.Drawing.Point(177, 111);
            this.partsLBL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.partsLBL.Name = "partsLBL";
            this.partsLBL.Size = new System.Drawing.Size(255, 37);
            this.partsLBL.TabIndex = 6;
            // 
            // serviceLaborLBL
            // 
            this.serviceLaborLBL.BackColor = System.Drawing.Color.LavenderBlush;
            this.serviceLaborLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.serviceLaborLBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceLaborLBL.Location = new System.Drawing.Point(205, 24);
            this.serviceLaborLBL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.serviceLaborLBL.Name = "serviceLaborLBL";
            this.serviceLaborLBL.Size = new System.Drawing.Size(199, 42);
            this.serviceLaborLBL.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(49, 287);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Total Fees";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(49, 212);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Tax (on parts)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 112);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Labor and Parts";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(89, 26);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Services";
            // 
            // calculateBTN
            // 
            this.calculateBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateBTN.Location = new System.Drawing.Point(128, 565);
            this.calculateBTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(175, 53);
            this.calculateBTN.TabIndex = 5;
            this.calculateBTN.Text = "Calculate";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBTN.Location = new System.Drawing.Point(661, 565);
            this.clearBTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(175, 53);
            this.clearBTN.TabIndex = 6;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBTN.Location = new System.Drawing.Point(1159, 565);
            this.exitBTN.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(175, 53);
            this.exitBTN.TabIndex = 7;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 104);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(213, 24);
            this.label7.TabIndex = 4;
            this.label7.Text = "Enter total hours worked";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1456, 703);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox lubeCheckBOX;
        private System.Windows.Forms.CheckBox oilChangeBOX;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox transmissionFlushBOX;
        private System.Windows.Forms.CheckBox radiatorFlushBOX;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox tireRotationBox;
        private System.Windows.Forms.CheckBox replaceMufflerBOX;
        private System.Windows.Forms.CheckBox inspectionBOX;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox laborTXT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox partsTXT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label totalLBL;
        private System.Windows.Forms.Label partsTaxLBL;
        private System.Windows.Forms.Label partsLBL;
        private System.Windows.Forms.Label serviceLaborLBL;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Label label7;
    }
}

