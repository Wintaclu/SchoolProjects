﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stadiumSeating
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            // Clear all input and output text on the screen
            classATXT.Text = "";
            classBTXT.Text = "";
            classCTXT.Text = "";
            classALBL.Text = "";
            classBLBL.Text = "";
            classCLBL.Text = "";
            totalLBL.Text = "";
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            // Close the program
            this.Close();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            // declare ticket costs
            const decimal CLASSA = 15m, CLASSB = 12m, CLASSC = 9m;

            // recieve number of tickets sold from user
            decimal classATickets, classBTickets, classCTickets;

            classATickets = decimal.Parse(classATXT.Text);
            classBTickets = decimal.Parse(classBTXT.Text);
            classCTickets = decimal.Parse(classCTXT.Text);

            // calculate revenue
            decimal classARev, classBRev, classCRev;
            classARev = classATickets * CLASSA;
            classBRev = classBTickets * CLASSB;
            classCRev = classCTickets * CLASSC;

            //display output

            classALBL.Text = classARev.ToString("C");
            classBLBL.Text = classBRev.ToString("C");
            classCLBL.Text = classCRev.ToString("C");
            totalLBL.Text = (classARev + classBRev + classCRev).ToString("C");
        }
    }
}
