﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GradeTxt = New System.Windows.Forms.TextBox()
        Me.SubmitBtn = New System.Windows.Forms.Button()
        Me.gradeList = New System.Windows.Forms.ListBox()
        Me.calculate = New System.Windows.Forms.Button()
        Me.averageLBL = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(51, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter Student Grade"
        '
        'GradeTxt
        '
        Me.GradeTxt.Location = New System.Drawing.Point(172, 44)
        Me.GradeTxt.Name = "GradeTxt"
        Me.GradeTxt.Size = New System.Drawing.Size(306, 20)
        Me.GradeTxt.TabIndex = 1
        '
        'SubmitBtn
        '
        Me.SubmitBtn.Location = New System.Drawing.Point(242, 100)
        Me.SubmitBtn.Name = "SubmitBtn"
        Me.SubmitBtn.Size = New System.Drawing.Size(75, 23)
        Me.SubmitBtn.TabIndex = 2
        Me.SubmitBtn.Text = "Submit"
        Me.SubmitBtn.UseVisualStyleBackColor = True
        '
        'gradeList
        '
        Me.gradeList.FormattingEnabled = True
        Me.gradeList.Location = New System.Drawing.Point(35, 100)
        Me.gradeList.Name = "gradeList"
        Me.gradeList.Size = New System.Drawing.Size(197, 329)
        Me.gradeList.TabIndex = 3
        '
        'calculate
        '
        Me.calculate.Location = New System.Drawing.Point(403, 100)
        Me.calculate.Name = "calculate"
        Me.calculate.Size = New System.Drawing.Size(75, 23)
        Me.calculate.TabIndex = 4
        Me.calculate.Text = "Calculate Average"
        Me.calculate.UseVisualStyleBackColor = True
        '
        'averageLBL
        '
        Me.averageLBL.BackColor = System.Drawing.Color.SeaShell
        Me.averageLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.averageLBL.Location = New System.Drawing.Point(242, 185)
        Me.averageLBL.Name = "averageLBL"
        Me.averageLBL.Size = New System.Drawing.Size(236, 170)
        Me.averageLBL.TabIndex = 5
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(710, 506)
        Me.Controls.Add(Me.averageLBL)
        Me.Controls.Add(Me.calculate)
        Me.Controls.Add(Me.gradeList)
        Me.Controls.Add(Me.SubmitBtn)
        Me.Controls.Add(Me.GradeTxt)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents GradeTxt As TextBox
    Friend WithEvents SubmitBtn As Button
    Friend WithEvents gradeList As ListBox
    Friend WithEvents calculate As Button
    Friend WithEvents averageLBL As Label
End Class
