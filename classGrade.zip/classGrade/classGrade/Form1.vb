﻿Public Class Form1
    Private Sub SubmitBtn_Click(sender As Object, e As EventArgs) Handles SubmitBtn.Click
        ' add items to the listbox

        Dim grade As Double
        grade = GradeTxt.Text
        If GradeTxt.Text <> String.Empty Then
            gradeList.Items.Add(grade.ToString())
        Else
            GradeTxt.Focus()
        End If
    End Sub

    Private Sub calculate_Click(sender As Object, e As EventArgs) Handles calculate.Click
        'variable for count of items in listbox
        'accumalator variable initiallize it to zero
        'use repitition statement to read from the list and find cumulator
        'find the average grade

        Dim count, gradeCount As Integer
        Dim total, average As Double

        count = gradeList.Items.Count
        total = 0
        gradeCount = 0

        Do While gradeCount < count
            total += gradeList.Items(gradeCount)
            gradeCount += 1
        Loop
        If gradeCount <> 0 Then
            average = total / count
            averageLBL.Text = "Total of " & count & "grades: " & total.ToString()
            averageLBL.Text = "Average grade: " & average.ToString()

        Else
            averageLBL.Text = "No grades entered"
        End If
    End Sub
End Class
