﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace distanceCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            double speed, time, distance;

            //get valid data from the user
            if(double.TryParse(speedTXT.Text, out speed) && double.TryParse(hoursTXT.Text, out time)) 
            {
                for(int i=1; i<=time; i++)
                {
                    distance = speed * i;
                    outputLIST.Items.Add("After hour " + i + " the distance is: " + distance);
                }
            }
            else
            {
                MessageBox.Show("Enter valid speed and time of travel");
            }
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            speedTXT.Text = "";
            hoursTXT.Text = "";
            outputLIST.Items.Clear();
            speedTXT.Focus();
        }
    }
}
