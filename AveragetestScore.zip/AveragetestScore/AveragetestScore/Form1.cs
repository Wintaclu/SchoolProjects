﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AveragetestScore
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            try
            {

                //declare input and output variables
                double test1, test2, test3, average;
                // recieve input
                test1 = double.Parse(test1TXT.Text);
                test2 = double.Parse(test2TXT.Text);
                test3 = double.Parse(test3TXT.Text);

                //calculate the average
                average = (test1 + test2 + test3) / 3.0;
                //display the average

                outputLBL.Text = average.ToString("n2");

                //add color to eit button
                exitBTN.BackColor = Color.Aqua;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Invalid data");
            }

        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            test1TXT.Text = "";
            test2TXT.Text = "";
            test3TXT.Text = "";
            outputLBL.Text = "";
            test1TXT.Focus();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
