﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bonusCapitalize
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void capsBTN_Click(object sender, EventArgs e)
        {
            bool Upper = true;
            foreach (char c in inputTXT.Text)//this cheks the characters one by one
            {
                if (Upper == true)
                {
                    if (c == ' ')
                    {
                        outputTXT.Text += c; //this moves the checker along for a space
                        continue;
                    }
                    outputTXT.Text += c.ToString().ToUpper(); 
                    Upper = false;
                }
                else
                {
                    outputTXT.Text += c;
                }
                if (c == '?' || c == '!' || c == '.')
                    Upper = true;


            }
        }

    }
}
