﻿namespace bonusCapitalize
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.capsBTN = new System.Windows.Forms.Button();
            this.inputTXT = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.outputTXT = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // capsBTN
            // 
            this.capsBTN.Location = new System.Drawing.Point(63, 254);
            this.capsBTN.Name = "capsBTN";
            this.capsBTN.Size = new System.Drawing.Size(143, 130);
            this.capsBTN.TabIndex = 0;
            this.capsBTN.Text = "Capitalize";
            this.capsBTN.UseVisualStyleBackColor = true;
            this.capsBTN.Click += new System.EventHandler(this.capsBTN_Click);
            // 
            // inputTXT
            // 
            this.inputTXT.Location = new System.Drawing.Point(243, 56);
            this.inputTXT.Multiline = true;
            this.inputTXT.Name = "inputTXT";
            this.inputTXT.Size = new System.Drawing.Size(426, 120);
            this.inputTXT.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter text to be capitlized";
            // 
            // outputTXT
            // 
            this.outputTXT.Location = new System.Drawing.Point(237, 208);
            this.outputTXT.Multiline = true;
            this.outputTXT.Name = "outputTXT";
            this.outputTXT.Size = new System.Drawing.Size(426, 120);
            this.outputTXT.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(901, 536);
            this.Controls.Add(this.outputTXT);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputTXT);
            this.Controls.Add(this.capsBTN);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button capsBTN;
        private System.Windows.Forms.TextBox inputTXT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox outputTXT;
    }
}

