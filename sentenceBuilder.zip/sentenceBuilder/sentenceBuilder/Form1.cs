﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sentenceBuilder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void clearBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = "";
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void capABTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "A";
        }

        private void aBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "a";
        }

        private void capAnBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "An";
        }

        private void anBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "an";
        }

        private void capTheBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "The";
        }

        private void theBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "the";
        }

        private void manBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "man";
        }

        private void womanBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "woman";
        }

        private void dogBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "dog";
        }

        private void catBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "cat";
        }

        private void carBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "car";
        }

        private void bicycleBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "bicycle";
        }

        private void beautifulBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "beautiful";
        }

        private void bigBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "big";
        }

        private void smallBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "small";
        }

        private void strangeBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "strange";
        }

        private void lookedBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "looked at";
        }

        private void rodeBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "rode";
        }

        private void spokeBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "spoke";
        }

        private void laughedBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "laughed at";
        }

        private void droveBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "drove";
        }

        private void spaceBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + " ";
        }

        private void periodBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + ".";
        }

        private void exclamationBTN_Click(object sender, EventArgs e)
        {
            outputLBL.Text = outputLBL.Text + "!";
        }
    }
}
