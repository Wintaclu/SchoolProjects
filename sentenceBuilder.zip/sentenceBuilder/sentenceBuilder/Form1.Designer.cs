﻿namespace sentenceBuilder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.capABTN = new System.Windows.Forms.Button();
            this.outputLBL = new System.Windows.Forms.Label();
            this.aBTN = new System.Windows.Forms.Button();
            this.capAnBTN = new System.Windows.Forms.Button();
            this.anBTN = new System.Windows.Forms.Button();
            this.capTheBTN = new System.Windows.Forms.Button();
            this.theBTN = new System.Windows.Forms.Button();
            this.manBTN = new System.Windows.Forms.Button();
            this.womanBTN = new System.Windows.Forms.Button();
            this.dogBTN = new System.Windows.Forms.Button();
            this.catBTN = new System.Windows.Forms.Button();
            this.carBTN = new System.Windows.Forms.Button();
            this.bicycleBTN = new System.Windows.Forms.Button();
            this.beautifulBTN = new System.Windows.Forms.Button();
            this.bigBTN = new System.Windows.Forms.Button();
            this.smallBTN = new System.Windows.Forms.Button();
            this.strangeBTN = new System.Windows.Forms.Button();
            this.lookedBTN = new System.Windows.Forms.Button();
            this.rodeBTN = new System.Windows.Forms.Button();
            this.spokeBTN = new System.Windows.Forms.Button();
            this.laughedBTN = new System.Windows.Forms.Button();
            this.droveBTN = new System.Windows.Forms.Button();
            this.spaceBTN = new System.Windows.Forms.Button();
            this.periodBTN = new System.Windows.Forms.Button();
            this.exclamationBTN = new System.Windows.Forms.Button();
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // capABTN
            // 
            this.capABTN.Location = new System.Drawing.Point(210, 33);
            this.capABTN.Name = "capABTN";
            this.capABTN.Size = new System.Drawing.Size(37, 34);
            this.capABTN.TabIndex = 0;
            this.capABTN.Text = "A";
            this.capABTN.UseVisualStyleBackColor = true;
            this.capABTN.Click += new System.EventHandler(this.capABTN_Click);
            // 
            // outputLBL
            // 
            this.outputLBL.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.outputLBL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLBL.Location = new System.Drawing.Point(44, 285);
            this.outputLBL.Name = "outputLBL";
            this.outputLBL.Size = new System.Drawing.Size(693, 40);
            this.outputLBL.TabIndex = 1;
            this.outputLBL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // aBTN
            // 
            this.aBTN.Location = new System.Drawing.Point(268, 33);
            this.aBTN.Name = "aBTN";
            this.aBTN.Size = new System.Drawing.Size(38, 34);
            this.aBTN.TabIndex = 2;
            this.aBTN.Text = "a";
            this.aBTN.UseVisualStyleBackColor = true;
            this.aBTN.Click += new System.EventHandler(this.aBTN_Click);
            // 
            // capAnBTN
            // 
            this.capAnBTN.Location = new System.Drawing.Point(327, 33);
            this.capAnBTN.Name = "capAnBTN";
            this.capAnBTN.Size = new System.Drawing.Size(42, 34);
            this.capAnBTN.TabIndex = 3;
            this.capAnBTN.Text = "An";
            this.capAnBTN.UseVisualStyleBackColor = true;
            this.capAnBTN.Click += new System.EventHandler(this.capAnBTN_Click);
            // 
            // anBTN
            // 
            this.anBTN.Location = new System.Drawing.Point(388, 33);
            this.anBTN.Name = "anBTN";
            this.anBTN.Size = new System.Drawing.Size(40, 34);
            this.anBTN.TabIndex = 4;
            this.anBTN.Text = "an";
            this.anBTN.UseVisualStyleBackColor = true;
            this.anBTN.Click += new System.EventHandler(this.anBTN_Click);
            // 
            // capTheBTN
            // 
            this.capTheBTN.Location = new System.Drawing.Point(451, 33);
            this.capTheBTN.Name = "capTheBTN";
            this.capTheBTN.Size = new System.Drawing.Size(42, 34);
            this.capTheBTN.TabIndex = 5;
            this.capTheBTN.Text = "The";
            this.capTheBTN.UseVisualStyleBackColor = true;
            this.capTheBTN.Click += new System.EventHandler(this.capTheBTN_Click);
            // 
            // theBTN
            // 
            this.theBTN.Location = new System.Drawing.Point(515, 33);
            this.theBTN.Name = "theBTN";
            this.theBTN.Size = new System.Drawing.Size(41, 34);
            this.theBTN.TabIndex = 6;
            this.theBTN.Text = "the";
            this.theBTN.UseVisualStyleBackColor = true;
            this.theBTN.Click += new System.EventHandler(this.theBTN_Click);
            // 
            // manBTN
            // 
            this.manBTN.Location = new System.Drawing.Point(139, 82);
            this.manBTN.Name = "manBTN";
            this.manBTN.Size = new System.Drawing.Size(55, 34);
            this.manBTN.TabIndex = 7;
            this.manBTN.Text = "man";
            this.manBTN.UseVisualStyleBackColor = true;
            this.manBTN.Click += new System.EventHandler(this.manBTN_Click);
            // 
            // womanBTN
            // 
            this.womanBTN.Location = new System.Drawing.Point(218, 82);
            this.womanBTN.Name = "womanBTN";
            this.womanBTN.Size = new System.Drawing.Size(87, 34);
            this.womanBTN.TabIndex = 8;
            this.womanBTN.Text = "woman";
            this.womanBTN.UseVisualStyleBackColor = true;
            this.womanBTN.Click += new System.EventHandler(this.womanBTN_Click);
            // 
            // dogBTN
            // 
            this.dogBTN.Location = new System.Drawing.Point(325, 82);
            this.dogBTN.Name = "dogBTN";
            this.dogBTN.Size = new System.Drawing.Size(47, 34);
            this.dogBTN.TabIndex = 9;
            this.dogBTN.Text = "dog";
            this.dogBTN.UseVisualStyleBackColor = true;
            this.dogBTN.Click += new System.EventHandler(this.dogBTN_Click);
            // 
            // catBTN
            // 
            this.catBTN.Location = new System.Drawing.Point(398, 82);
            this.catBTN.Name = "catBTN";
            this.catBTN.Size = new System.Drawing.Size(46, 34);
            this.catBTN.TabIndex = 10;
            this.catBTN.Text = "cat";
            this.catBTN.UseVisualStyleBackColor = true;
            this.catBTN.Click += new System.EventHandler(this.catBTN_Click);
            // 
            // carBTN
            // 
            this.carBTN.Location = new System.Drawing.Point(467, 82);
            this.carBTN.Name = "carBTN";
            this.carBTN.Size = new System.Drawing.Size(45, 34);
            this.carBTN.TabIndex = 11;
            this.carBTN.Text = "car";
            this.carBTN.UseVisualStyleBackColor = true;
            this.carBTN.Click += new System.EventHandler(this.carBTN_Click);
            // 
            // bicycleBTN
            // 
            this.bicycleBTN.Location = new System.Drawing.Point(532, 82);
            this.bicycleBTN.Name = "bicycleBTN";
            this.bicycleBTN.Size = new System.Drawing.Size(73, 34);
            this.bicycleBTN.TabIndex = 12;
            this.bicycleBTN.Text = "bicycle";
            this.bicycleBTN.UseVisualStyleBackColor = true;
            this.bicycleBTN.Click += new System.EventHandler(this.bicycleBTN_Click);
            // 
            // beautifulBTN
            // 
            this.beautifulBTN.Location = new System.Drawing.Point(201, 122);
            this.beautifulBTN.Name = "beautifulBTN";
            this.beautifulBTN.Size = new System.Drawing.Size(87, 34);
            this.beautifulBTN.TabIndex = 13;
            this.beautifulBTN.Text = "beautiful";
            this.beautifulBTN.UseVisualStyleBackColor = true;
            this.beautifulBTN.Click += new System.EventHandler(this.beautifulBTN_Click);
            // 
            // bigBTN
            // 
            this.bigBTN.Location = new System.Drawing.Point(312, 122);
            this.bigBTN.Name = "bigBTN";
            this.bigBTN.Size = new System.Drawing.Size(42, 34);
            this.bigBTN.TabIndex = 14;
            this.bigBTN.Text = "big";
            this.bigBTN.UseVisualStyleBackColor = true;
            this.bigBTN.Click += new System.EventHandler(this.bigBTN_Click);
            // 
            // smallBTN
            // 
            this.smallBTN.Location = new System.Drawing.Point(377, 122);
            this.smallBTN.Name = "smallBTN";
            this.smallBTN.Size = new System.Drawing.Size(51, 34);
            this.smallBTN.TabIndex = 15;
            this.smallBTN.Text = "small";
            this.smallBTN.UseVisualStyleBackColor = true;
            this.smallBTN.Click += new System.EventHandler(this.smallBTN_Click);
            // 
            // strangeBTN
            // 
            this.strangeBTN.Location = new System.Drawing.Point(451, 122);
            this.strangeBTN.Name = "strangeBTN";
            this.strangeBTN.Size = new System.Drawing.Size(87, 34);
            this.strangeBTN.TabIndex = 16;
            this.strangeBTN.Text = "strange";
            this.strangeBTN.UseVisualStyleBackColor = true;
            this.strangeBTN.Click += new System.EventHandler(this.strangeBTN_Click);
            // 
            // lookedBTN
            // 
            this.lookedBTN.Location = new System.Drawing.Point(107, 175);
            this.lookedBTN.Name = "lookedBTN";
            this.lookedBTN.Size = new System.Drawing.Size(87, 34);
            this.lookedBTN.TabIndex = 17;
            this.lookedBTN.Text = "looked at";
            this.lookedBTN.UseVisualStyleBackColor = true;
            this.lookedBTN.Click += new System.EventHandler(this.lookedBTN_Click);
            // 
            // rodeBTN
            // 
            this.rodeBTN.Location = new System.Drawing.Point(218, 175);
            this.rodeBTN.Name = "rodeBTN";
            this.rodeBTN.Size = new System.Drawing.Size(48, 34);
            this.rodeBTN.TabIndex = 18;
            this.rodeBTN.Text = "rode";
            this.rodeBTN.UseVisualStyleBackColor = true;
            this.rodeBTN.Click += new System.EventHandler(this.rodeBTN_Click);
            // 
            // spokeBTN
            // 
            this.spokeBTN.Location = new System.Drawing.Point(300, 175);
            this.spokeBTN.Name = "spokeBTN";
            this.spokeBTN.Size = new System.Drawing.Size(69, 34);
            this.spokeBTN.TabIndex = 19;
            this.spokeBTN.Text = "spoke to";
            this.spokeBTN.UseVisualStyleBackColor = true;
            this.spokeBTN.Click += new System.EventHandler(this.spokeBTN_Click);
            // 
            // laughedBTN
            // 
            this.laughedBTN.Location = new System.Drawing.Point(396, 175);
            this.laughedBTN.Name = "laughedBTN";
            this.laughedBTN.Size = new System.Drawing.Size(87, 34);
            this.laughedBTN.TabIndex = 20;
            this.laughedBTN.Text = "laughed at";
            this.laughedBTN.UseVisualStyleBackColor = true;
            this.laughedBTN.Click += new System.EventHandler(this.laughedBTN_Click);
            // 
            // droveBTN
            // 
            this.droveBTN.Location = new System.Drawing.Point(515, 175);
            this.droveBTN.Name = "droveBTN";
            this.droveBTN.Size = new System.Drawing.Size(67, 34);
            this.droveBTN.TabIndex = 21;
            this.droveBTN.Text = "drove";
            this.droveBTN.UseVisualStyleBackColor = true;
            this.droveBTN.Click += new System.EventHandler(this.droveBTN_Click);
            // 
            // spaceBTN
            // 
            this.spaceBTN.Location = new System.Drawing.Point(252, 227);
            this.spaceBTN.Name = "spaceBTN";
            this.spaceBTN.Size = new System.Drawing.Size(87, 34);
            this.spaceBTN.TabIndex = 22;
            this.spaceBTN.Text = "(Space)";
            this.spaceBTN.UseVisualStyleBackColor = true;
            this.spaceBTN.Click += new System.EventHandler(this.spaceBTN_Click);
            // 
            // periodBTN
            // 
            this.periodBTN.Location = new System.Drawing.Point(362, 227);
            this.periodBTN.Name = "periodBTN";
            this.periodBTN.Size = new System.Drawing.Size(42, 34);
            this.periodBTN.TabIndex = 23;
            this.periodBTN.Text = ".";
            this.periodBTN.UseVisualStyleBackColor = true;
            this.periodBTN.Click += new System.EventHandler(this.periodBTN_Click);
            // 
            // exclamationBTN
            // 
            this.exclamationBTN.Location = new System.Drawing.Point(426, 227);
            this.exclamationBTN.Name = "exclamationBTN";
            this.exclamationBTN.Size = new System.Drawing.Size(41, 34);
            this.exclamationBTN.TabIndex = 24;
            this.exclamationBTN.Text = "!";
            this.exclamationBTN.UseVisualStyleBackColor = true;
            this.exclamationBTN.Click += new System.EventHandler(this.exclamationBTN_Click);
            // 
            // clearBTN
            // 
            this.clearBTN.Location = new System.Drawing.Point(254, 376);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(87, 34);
            this.clearBTN.TabIndex = 25;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Location = new System.Drawing.Point(388, 376);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(87, 34);
            this.exitBTN.TabIndex = 26;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.exclamationBTN);
            this.Controls.Add(this.periodBTN);
            this.Controls.Add(this.spaceBTN);
            this.Controls.Add(this.droveBTN);
            this.Controls.Add(this.laughedBTN);
            this.Controls.Add(this.spokeBTN);
            this.Controls.Add(this.rodeBTN);
            this.Controls.Add(this.lookedBTN);
            this.Controls.Add(this.strangeBTN);
            this.Controls.Add(this.smallBTN);
            this.Controls.Add(this.bigBTN);
            this.Controls.Add(this.beautifulBTN);
            this.Controls.Add(this.bicycleBTN);
            this.Controls.Add(this.carBTN);
            this.Controls.Add(this.catBTN);
            this.Controls.Add(this.dogBTN);
            this.Controls.Add(this.womanBTN);
            this.Controls.Add(this.manBTN);
            this.Controls.Add(this.theBTN);
            this.Controls.Add(this.capTheBTN);
            this.Controls.Add(this.anBTN);
            this.Controls.Add(this.capAnBTN);
            this.Controls.Add(this.aBTN);
            this.Controls.Add(this.outputLBL);
            this.Controls.Add(this.capABTN);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button capABTN;
        private System.Windows.Forms.Label outputLBL;
        private System.Windows.Forms.Button aBTN;
        private System.Windows.Forms.Button capAnBTN;
        private System.Windows.Forms.Button anBTN;
        private System.Windows.Forms.Button capTheBTN;
        private System.Windows.Forms.Button theBTN;
        private System.Windows.Forms.Button manBTN;
        private System.Windows.Forms.Button womanBTN;
        private System.Windows.Forms.Button dogBTN;
        private System.Windows.Forms.Button catBTN;
        private System.Windows.Forms.Button carBTN;
        private System.Windows.Forms.Button bicycleBTN;
        private System.Windows.Forms.Button beautifulBTN;
        private System.Windows.Forms.Button bigBTN;
        private System.Windows.Forms.Button smallBTN;
        private System.Windows.Forms.Button strangeBTN;
        private System.Windows.Forms.Button lookedBTN;
        private System.Windows.Forms.Button rodeBTN;
        private System.Windows.Forms.Button spokeBTN;
        private System.Windows.Forms.Button laughedBTN;
        private System.Windows.Forms.Button droveBTN;
        private System.Windows.Forms.Button spaceBTN;
        private System.Windows.Forms.Button periodBTN;
        private System.Windows.Forms.Button exclamationBTN;
        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
    }
}

