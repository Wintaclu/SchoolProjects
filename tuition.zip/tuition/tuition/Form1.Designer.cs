﻿namespace tuition
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clearBTN = new System.Windows.Forms.Button();
            this.exitBTN = new System.Windows.Forms.Button();
            this.calculateBTN = new System.Windows.Forms.Button();
            this.outputLIST = new System.Windows.Forms.ListBox();
            this.increaseTXT = new System.Windows.Forms.TextBox();
            this.tuitionTXT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.yearsTXT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // clearBTN
            // 
            this.clearBTN.Font = new System.Drawing.Font("Mistral", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBTN.Location = new System.Drawing.Point(473, 157);
            this.clearBTN.Name = "clearBTN";
            this.clearBTN.Size = new System.Drawing.Size(106, 59);
            this.clearBTN.TabIndex = 15;
            this.clearBTN.Text = "Clear";
            this.clearBTN.UseVisualStyleBackColor = true;
            this.clearBTN.Click += new System.EventHandler(this.clearBTN_Click);
            // 
            // exitBTN
            // 
            this.exitBTN.Font = new System.Drawing.Font("Mistral", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBTN.Location = new System.Drawing.Point(473, 254);
            this.exitBTN.Name = "exitBTN";
            this.exitBTN.Size = new System.Drawing.Size(106, 59);
            this.exitBTN.TabIndex = 14;
            this.exitBTN.Text = "Exit";
            this.exitBTN.UseVisualStyleBackColor = true;
            this.exitBTN.Click += new System.EventHandler(this.exitBTN_Click);
            // 
            // calculateBTN
            // 
            this.calculateBTN.Font = new System.Drawing.Font("Mistral", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateBTN.Location = new System.Drawing.Point(473, 66);
            this.calculateBTN.Name = "calculateBTN";
            this.calculateBTN.Size = new System.Drawing.Size(106, 59);
            this.calculateBTN.TabIndex = 13;
            this.calculateBTN.Text = "Calculaate";
            this.calculateBTN.UseVisualStyleBackColor = true;
            this.calculateBTN.Click += new System.EventHandler(this.calculateBTN_Click);
            // 
            // outputLIST
            // 
            this.outputLIST.FormattingEnabled = true;
            this.outputLIST.Location = new System.Drawing.Point(97, 157);
            this.outputLIST.Name = "outputLIST";
            this.outputLIST.Size = new System.Drawing.Size(328, 303);
            this.outputLIST.TabIndex = 12;
            // 
            // increaseTXT
            // 
            this.increaseTXT.Location = new System.Drawing.Point(281, 66);
            this.increaseTXT.Name = "increaseTXT";
            this.increaseTXT.Size = new System.Drawing.Size(100, 20);
            this.increaseTXT.TabIndex = 11;
            // 
            // tuitionTXT
            // 
            this.tuitionTXT.Location = new System.Drawing.Point(271, 34);
            this.tuitionTXT.Name = "tuitionTXT";
            this.tuitionTXT.Size = new System.Drawing.Size(100, 20);
            this.tuitionTXT.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(129, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Percent Increase";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(154, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tuition Cost:";
            // 
            // yearsTXT
            // 
            this.yearsTXT.Location = new System.Drawing.Point(281, 104);
            this.yearsTXT.Name = "yearsTXT";
            this.yearsTXT.Size = new System.Drawing.Size(100, 20);
            this.yearsTXT.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(214, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 20);
            this.label3.TabIndex = 16;
            this.label3.Text = "Years:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 495);
            this.Controls.Add(this.yearsTXT);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.clearBTN);
            this.Controls.Add(this.exitBTN);
            this.Controls.Add(this.calculateBTN);
            this.Controls.Add(this.outputLIST);
            this.Controls.Add(this.increaseTXT);
            this.Controls.Add(this.tuitionTXT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button clearBTN;
        private System.Windows.Forms.Button exitBTN;
        private System.Windows.Forms.Button calculateBTN;
        private System.Windows.Forms.ListBox outputLIST;
        private System.Windows.Forms.TextBox increaseTXT;
        private System.Windows.Forms.TextBox tuitionTXT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox yearsTXT;
        private System.Windows.Forms.Label label3;
    }
}

