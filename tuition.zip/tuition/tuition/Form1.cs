﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tuition
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitBTN_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearBTN_Click(object sender, EventArgs e)
        {
            tuitionTXT.Text = "";
            increaseTXT.Text = "";
            yearsTXT.Text = "";
            outputLIST.Items.Clear();
        }

        private void calculateBTN_Click(object sender, EventArgs e)
        {
            double tuition, increase, years;

            if (double.TryParse(tuitionTXT.Text, out tuition) && double.TryParse(increaseTXT.Text, out increase) && double.TryParse(yearsTXT.Text, out years))
            {
                increase = increase / 100;
                for (int i = 1; i <= years; i++)
                {
                    
                    outputLIST.Items.Add("Year " + i + " the cost of tuition is: " + tuition.ToString("C"));
                    tuition = tuition + (tuition * increase);
                    
                }
            }
            else
            {
                MessageBox.Show("Enter valid data");
            }
        }
    }
}
