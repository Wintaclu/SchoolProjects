﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace slotmachine
{
    
    public partial class Form1 : Form

    {
        private int amntOfWins;
        private double totalMoneyWon;

        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }




        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Submit_Click(object sender, EventArgs e)
        {

            double amount=0; 
            try
            {
                amount = double.Parse(amountBox.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Enter a valid number");
            }

            Random rand = new Random();

            int slot1 = rand.Next(imageList1.Images.Count);
            int slot2 = rand.Next(imageList1.Images.Count);
            int slot3 = rand.Next(imageList1.Images.Count);

            slot1 = rand.Next(imageList1.Images.Count);
            slotPic1.Image = imageList1.Images[slot1];
            

            slot2 = rand.Next(imageList1.Images.Count);
            slotPic2.Image = imageList1.Images[slot2];
            

            slot3 = rand.Next(imageList1.Images.Count);
            slotPic3.Image = imageList1.Images[slot3];
            

            if ((slot1 == slot2 && slot1 !=slot3 && slot2!=slot3)|| (slot1 == slot3 && slot1!=slot2 && slot3!=slot2)|| (slot2 == slot3 && slot2!=slot1 && slot3!= slot1))
            {
                amntOfWins += 1;
                totalMoneyWon = totalMoneyWon + (amount * 2);
                MessageBox.Show("You have won $" + (amount * 2)) ;
            }
            else if (slot1 == slot2 && slot1 == slot3 && slot2==slot3 )
            {
                amntOfWins += 1;
                totalMoneyWon = totalMoneyWon + (amount * 3);
                MessageBox.Show("You have won $" + (amount*3));
            }
            else if ((slot1 != slot2 && slot1 != slot3 && slot2!=slot3))
            {
                MessageBox.Show("You have won $0");
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The total number of wins is " + amntOfWins + ". The total amount of money earned is $" + totalMoneyWon);
            this.Close();
        }
    }
}
