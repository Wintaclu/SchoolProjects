﻿namespace slotmachine
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.slotPic1 = new System.Windows.Forms.PictureBox();
            this.slotPic2 = new System.Windows.Forms.PictureBox();
            this.slotPic3 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.amountBox = new System.Windows.Forms.TextBox();
            this.spinBtn = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.slotPic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotPic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotPic3)).BeginInit();
            this.SuspendLayout();
            // 
            // slotPic1
            // 
            this.slotPic1.Location = new System.Drawing.Point(0, 0);
            this.slotPic1.Name = "slotPic1";
            this.slotPic1.Size = new System.Drawing.Size(258, 267);
            this.slotPic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slotPic1.TabIndex = 0;
            this.slotPic1.TabStop = false;
            // 
            // slotPic2
            // 
            this.slotPic2.Location = new System.Drawing.Point(384, 0);
            this.slotPic2.Name = "slotPic2";
            this.slotPic2.Size = new System.Drawing.Size(258, 267);
            this.slotPic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slotPic2.TabIndex = 1;
            this.slotPic2.TabStop = false;
            // 
            // slotPic3
            // 
            this.slotPic3.Location = new System.Drawing.Point(748, 0);
            this.slotPic3.Name = "slotPic3";
            this.slotPic3.Size = new System.Drawing.Size(258, 267);
            this.slotPic3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slotPic3.TabIndex = 2;
            this.slotPic3.TabStop = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(380, 336);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 26);
            this.label1.TabIndex = 3;
            this.label1.Text = "Amount Inserted: $";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Lucky_Seven.png");
            this.imageList1.Images.SetKeyName(1, "Diamond.png");
            this.imageList1.Images.SetKeyName(2, "Coins.png");
            // 
            // amountBox
            // 
            this.amountBox.Location = new System.Drawing.Point(548, 336);
            this.amountBox.Name = "amountBox";
            this.amountBox.Size = new System.Drawing.Size(134, 20);
            this.amountBox.TabIndex = 4;
            // 
            // spinBtn
            // 
            this.spinBtn.Location = new System.Drawing.Point(384, 473);
            this.spinBtn.Name = "spinBtn";
            this.spinBtn.Size = new System.Drawing.Size(75, 23);
            this.spinBtn.TabIndex = 5;
            this.spinBtn.Text = "Spin";
            this.spinBtn.UseVisualStyleBackColor = true;
            this.spinBtn.Click += new System.EventHandler(this.Submit_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(607, 473);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 23);
            this.Exit.TabIndex = 6;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1062, 549);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.spinBtn);
            this.Controls.Add(this.amountBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.slotPic3);
            this.Controls.Add(this.slotPic2);
            this.Controls.Add(this.slotPic1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.slotPic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotPic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotPic3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox slotPic1;
        private System.Windows.Forms.PictureBox slotPic2;
        private System.Windows.Forms.PictureBox slotPic3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox amountBox;
        private System.Windows.Forms.Button spinBtn;
        private System.Windows.Forms.Button Exit;
    }
}

